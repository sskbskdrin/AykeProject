/*
 * Copyright (C) 2008 ZXing authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.zxing.client.android;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.ayke.library.util.SysUtils;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.Result;
import com.google.zxing.ResultPoint;
import com.google.zxing.client.android.tesseract.DictionaryEntity;
import com.google.zxing.client.android.tesseract.UnzipFromAssets;
import com.open.volley.Request;
import com.open.volley.VolleyError;
import com.open.volley.wrapper.IParseResponse;
import com.open.volley.wrapper.VolleyEncapsulation;
import com.open.volley.wrapper.VolleyJsonObjectRequest;
import com.zxing.client.R;

import java.io.IOException;
import java.security.cert.PolicyNode;
import java.util.HashMap;
import java.util.Map;

/**
 * This activity opens the camera and does the actual scanning on a background thread. It draws a
 * viewfinder to help the user place the barcode correctly, shows feedback as the image processing
 * is happening, and then overlays the results when a scan is successful.
 *
 * @author dswitkin@google.com (Daniel Switkin)
 * @author Sean Owen
 */
public final class CaptureActivity extends Activity implements SurfaceHolder.Callback {
	private static final String TAG = CaptureActivity.class.getSimpleName();

	private CodeViewfinderView codeViewfinderView;
	private SurfaceView surfaceView;
	private boolean change;
	private boolean hasSurface;

	public CodeViewfinderView getCodeViewfinderView() {
		return codeViewfinderView;
	}

	@Override
	public void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		Window window = getWindow();
		window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		SysUtils.init(getApplicationContext());
		ScanManager.init(this);
		VolleyEncapsulation.initVolley(this);
		setContentView(R.layout.capture);
		new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					UnzipFromAssets.unZip(getApplicationContext(), "dicts.zip", getFilesDir()
							.getAbsolutePath(), false);
					UnzipFromAssets.unZip(getApplicationContext(), "tessdata.zip", getFilesDir()
							.getAbsolutePath(), false);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}).start();

		hasSurface = false;
		codeViewfinderView = (CodeViewfinderView) findViewById(R.id.viewfinder_view);
		surfaceView = (SurfaceView) findViewById(R.id.preview_view);

		surfaceView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver
				.OnGlobalLayoutListener() {
			@Override
			public void onGlobalLayout() {
				Log.d("ayke", "onGlobalLayout surfaceView=" + surfaceView.getHolder()
						.getSurfaceFrame().toString());
				if (change) {
					change = false;
					changeSurfaceView();
					ScanManager.getInstance().changeOrientation();
				}
			}
		});

		findViewById(R.id.scan_code).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				ScanManager.getInstance().changeMode(ScanManager.ScanMode.CODE);
			}
		});
		findViewById(R.id.scan_word).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				ScanManager.getInstance().changeMode(ScanManager.ScanMode.WORD);
			}
		});
	}

	@Override
	protected void onResume() {
		super.onResume();
		Log.d("ayke", "onResume ");
		ScanManager.getInstance().onResume();
		SurfaceHolder surfaceHolder = surfaceView.getHolder();
		if (hasSurface) {
			ScanManager.getInstance().initCamera(surfaceHolder); // The activity was paused but
			changeSurfaceView();
			// not stopped, so the surface
			// still exists. Therefore surfaceCreated() won't be called, so init the camera here.
		} else {
			// Install the callback and wait for surfaceCreated() to init the camera.
			surfaceHolder.addCallback(this);
			surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
		}
	}

	@Override
	protected void onPause() {
		Log.d("ayke", "onPause ");
		ScanManager.getInstance().onPause();
		if (!hasSurface) {
			SurfaceHolder surfaceHolder = surfaceView.getHolder();
			surfaceHolder.removeCallback(this);
		}
		super.onPause();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		switch (keyCode) {
			case KeyEvent.KEYCODE_FOCUS:
			case KeyEvent.KEYCODE_CAMERA:
				// Handle these events so they don't launch the Camera app
				return true;
			// Use volume up/down to turn on light
			case KeyEvent.KEYCODE_VOLUME_DOWN:
				ScanManager.getInstance().getCameraManager().setTorch(false);
				return true;
			case KeyEvent.KEYCODE_VOLUME_UP:
				ScanManager.getInstance().getCameraManager().setTorch(true);
				return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		if (newConfig.orientation == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT) {
			Log.d("ayke", "SCREEN_ORIENTATION_PORTRAIT");
		} else if (newConfig.orientation == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) {
			Log.d("ayke", "SCREEN_ORIENTATION_LANDSCAPE");
		} else if (newConfig.orientation == ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT) {
			Log.d("ayke", "SCREEN_ORIENTATION_REVERSE_PORTRAIT");
		} else if (newConfig.orientation == ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE) {
			Log.d("ayke", "SCREEN_ORIENTATION_REVERSE_LANDSCAPE");
		} else {
			Log.d("ayke", "SCREEN_OTHER " + newConfig.orientation);
		}
		Log.d("ayke", "SCREEN_ " + getWindowManager().getDefaultDisplay().getRotation());
		change = true;
		super.onConfigurationChanged(newConfig);
	}

	private void changeSurfaceView() {
		int width = ((ViewGroup) surfaceView.getParent()).getWidth();
		int height = ((ViewGroup) surfaceView.getParent()).getHeight();
		Point point = new Point(width, height);
		ScanManager.getInstance().getCameraManager().findBestSurfacePoint(point);
		point = ScanManager.getInstance().getCameraManager().getSurfacePoint();
		if (point == null)
			return;
		surfaceView.getLayoutParams().width = point.x;
		surfaceView.getLayoutParams().height = point.y;
		surfaceView.requestLayout();
		codeViewfinderView.getLayoutParams().width = point.x;
		codeViewfinderView.getLayoutParams().height = point.y;
		codeViewfinderView.requestLayout();
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		if (holder == null) {
			Log.e(TAG, "*** WARNING *** surfaceCreated() gave us a null surface!");
		}
		if (!hasSurface) {
			hasSurface = true;
			ScanManager.getInstance().initCamera(holder);
			changeSurfaceView();
		}
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		hasSurface = false;
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
	                           int height) {
	}

	private DictionaryEntity mDictionaryEntity;

	public void handleWord(String word, final Bitmap bitmap) {
		if (mDictionaryEntity != null) {
			if (mDictionaryEntity.getName() != null && word.compareToIgnoreCase(mDictionaryEntity
					.getName())
					== 0)
				return;
		}
		String url = "http://apis.baidu.com/apistore/tranlateservice/dictionary?from=en&to=zh" +
				"&query=";
		VolleyJsonObjectRequest<DictionaryEntity> request = new
				VolleyJsonObjectRequest<DictionaryEntity>(url + word, new DictionaryEntity(), new
				VolleyJsonObjectRequest.IVolleyRequestListener() {
					@Override
					public void onVolleySuccess(IParseResponse result, boolean isSuccess, int id) {
						mDictionaryEntity = (DictionaryEntity) result;
						((TextView) findViewById(R.id.text)).setText(mDictionaryEntity.toString());
//						((ImageView) findViewById(R.id.img)).setImageBitmap(bitmap);
					}

					@Override
					public void onVolleyError(VolleyError error, int id) {
					}
				});
		Map<String, String> map = new HashMap<String, String>();
		map.put("apikey", "85bcbaf63a7b08e52614cc6771005a7f");
		request.setHeaders(map);
		VolleyEncapsulation.startRequest(request);
	}

	/**
	 * A valid barcode has been found, so give an indication of success and show the results.
	 *
	 * @param rawResult   The contents of the barcode.
	 * @param scaleFactor amount by which thumbnail was scaled
	 * @param barcode     A greyscale bitmap of the camera data which was decoded.
	 */
	public void handleDecode(Result rawResult, Bitmap barcode, float scaleFactor) {
/*		lastResult = rawResult;
		ResultHandler resultHandler = ResultHandlerFactory.makeResultHandler(this, rawResult);

		boolean fromLiveScan = barcode != null;
		if (fromLiveScan) {
			// Then not from history, so beep/vibrate and we have an image to draw on
			ScanManager.getInstance().getBeepManager().playBeepSoundAndVibrate();
			drawResultPoints(barcode, scaleFactor, rawResult);
		}
		Toast.makeText(this, "" + lastResult.getText(), Toast.LENGTH_SHORT).show();

    switch (source) {
      case NATIVE_APP_INTENT:
      case PRODUCT_SEARCH_LINK:
        handleDecodeExternally(rawResult, resultHandler, barcode);
        break;
      case ZXING_LINK:
        if (scanFromWebPageManager == null || !scanFromWebPageManager.isScanFromWebPage()) {
          handleDecodeInternally(rawResult, resultHandler, barcode);
        } else {
          handleDecodeExternally(rawResult, resultHandler, barcode);
        }
        break;
      case NONE:
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        if (fromLiveScan && prefs.getBoolean(PreferencesActivity.KEY_BULK_MODE, false)) {
          Toast.makeText(getApplicationContext(),
                         getResources().getString(R.string.msg_bulk_mode_scanned) + " (" +
                         rawResult.getText() + ')',
                         Toast.LENGTH_SHORT).show();
          // Wait a moment or else it will scan the same barcode continuously about 3 times
          restartPreviewAfterDelay(BULK_MODE_SCAN_DELAY_MS);
        } else {
          handleDecodeInternally(rawResult, resultHandler, barcode);
        }
        break;
    }
    */
	}

	/**
	 * Superimpose a line for 1D or dots for 2D to highlight the key features of the barcode.
	 *
	 * @param barcode     A bitmap of the captured image.
	 * @param scaleFactor amount by which thumbnail was scaled
	 * @param rawResult   The decoded results which contains the points to draw.
	 */
	private void drawResultPoints(Bitmap barcode, float scaleFactor, Result
			rawResult) {
		ResultPoint[] points = rawResult.getResultPoints();
		if (points != null && points.length > 0) {
			Canvas canvas = new Canvas(barcode);
			Paint paint = new Paint();
			paint.setColor(getResources().getColor(R.color.result_points));
			if (points.length == 2) {
				paint.setStrokeWidth(4.0f);
				drawLine(canvas, paint, points[0], points[1], scaleFactor);
			} else if (points.length == 4 &&
					(rawResult.getBarcodeFormat() == BarcodeFormat.UPC_A ||
							rawResult.getBarcodeFormat() == BarcodeFormat
									.EAN_13)) {
				// Hacky special case -- draw two lines, for the barcode and
				// metadata
				drawLine(canvas, paint, points[0], points[1], scaleFactor);
				drawLine(canvas, paint, points[2], points[3], scaleFactor);
			} else {
				paint.setStrokeWidth(10.0f);
				for (ResultPoint point : points) {
					if (point != null) {
						canvas.drawPoint(scaleFactor * point.getX(),
								scaleFactor * point.getY(), paint);
					}
				}
			}
		}
	}

	private static void drawLine(Canvas canvas, Paint paint, ResultPoint a,
	                             ResultPoint b, float scaleFactor) {
		if (a != null && b != null) {
			canvas.drawLine(scaleFactor * a.getX(),
					scaleFactor * a.getY(),
					scaleFactor * b.getX(),
					scaleFactor * b.getY(),
					paint);
		}
	}

	/**
	 * Put up our own UI for how to handle the decoded contents.
	 * private void handleDecodeInternally(Result rawResult, ResultHandler resultHandler, Bitmap
	 * barcode) {
	 * <p>
	 * CharSequence displayContents = resultHandler.getDisplayContents();
	 * <p>
	 * if (copyToClipboard && !resultHandler.areContentsSecure()) {
	 * ClipboardInterface.setText(displayContents, this);
	 * }
	 * <p>
	 * SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
	 * <p>
	 * if (resultHandler.getDefaultButtonID() != null && prefs.getBoolean(PreferencesActivity
	 * .KEY_AUTO_OPEN_WEB, false)) {
	 * resultHandler.handleButtonPress(resultHandler.getDefaultButtonID());
	 * return;
	 * }
	 * <p>
	 * statusView.setVisibility(View.GONE);
	 * viewfinderView.setVisibility(View.GONE);
	 * resultView.setVisibility(View.VISIBLE);
	 * <p>
	 * ImageView barcodeImageView = (ImageView) findViewById(R.id.barcode_image_view);
	 * if (barcode == null) {
	 * barcodeImageView.setImageBitmap(BitmapFactory.decodeResource(getResources(),
	 * R.drawable.launcher_icon));
	 * } else {
	 * barcodeImageView.setImageBitmap(barcode);
	 * }
	 * <p>
	 * TextView formatTextView = (TextView) findViewById(R.id.format_text_view);
	 * formatTextView.setText(rawResult.getBarcodeFormat().toString());
	 * <p>
	 * TextView typeTextView = (TextView) findViewById(R.id.type_text_view);
	 * typeTextView.setText(resultHandler.getType().toString());
	 * <p>
	 * DateFormat formatter = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT);
	 * TextView timeTextView = (TextView) findViewById(R.id.time_text_view);
	 * timeTextView.setText(formatter.format(new Date(rawResult.getTimestamp())));
	 * <p>
	 * <p>
	 * TextView metaTextView = (TextView) findViewById(R.id.meta_text_view);
	 * View metaTextViewLabel = findViewById(R.id.meta_text_view_label);
	 * metaTextView.setVisibility(View.GONE);
	 * metaTextViewLabel.setVisibility(View.GONE);
	 * Map<ResultMetadataType, Object> metadata = rawResult.getResultMetadata();
	 * if (metadata != null) {
	 * StringBuilder metadataText = new StringBuilder(20);
	 * for (Map.Entry<ResultMetadataType, Object> entry : metadata.entrySet()) {
	 * if (DISPLAYABLE_METADATA_TYPES.contains(entry.getKey())) {
	 * metadataText.append(entry.getValue()).append('\n');
	 * }
	 * }
	 * if (metadataText.length() > 0) {
	 * metadataText.setLength(metadataText.length() - 1);
	 * metaTextView.setText(metadataText);
	 * metaTextView.setVisibility(View.VISIBLE);
	 * metaTextViewLabel.setVisibility(View.VISIBLE);
	 * }
	 * }
	 * <p>
	 * TextView contentsTextView = (TextView) findViewById(R.id.contents_text_view);
	 * contentsTextView.setText(displayContents);
	 * int scaledSize = Math.max(22, 32 - displayContents.length() / 4);
	 * contentsTextView.setTextSize(TypedValue.COMPLEX_UNIT_SP, scaledSize);
	 * <p>
	 * TextView supplementTextView = (TextView) findViewById(R.id.contents_supplement_text_view);
	 * supplementTextView.setText("");
	 * supplementTextView.setOnClickListener(null);
	 * if (PreferenceManager.getDefaultSharedPreferences(this).getBoolean(
	 * PreferencesActivity.KEY_SUPPLEMENTAL, true)) {
	 * }
	 * <p>
	 * int buttonCount = resultHandler.getButtonCount();
	 * ViewGroup buttonView = (ViewGroup) findViewById(R.id.result_button_view);
	 * buttonView.requestFocus();
	 * for (int x = 0; x < ResultHandler.MAX_BUTTON_COUNT; x++) {
	 * TextView button = (TextView) buttonView.getChildAt(x);
	 * if (x < buttonCount) {
	 * button.setVisibility(View.VISIBLE);
	 * button.setText(resultHandler.getButtonText(x));
	 * button.setOnClickListener(new ResultButtonListener(resultHandler, x));
	 * } else {
	 * button.setVisibility(View.GONE);
	 * }
	 * }
	 * <p>
	 * }
	 * <p>
	 * // Briefly show the contents of the barcode, then handle the result outside Barcode Scanner.
	 * private void handleDecodeExternally(Result rawResult, ResultHandler resultHandler, Bitmap
	 * barcode) {
	 * <p>
	 * if (barcode != null) {
	 * viewfinderView.drawResultBitmap(barcode);
	 * }
	 * <p>
	 * long resultDurationMS;
	 * if (getIntent() == null) {
	 * resultDurationMS = DEFAULT_INTENT_RESULT_DURATION_MS;
	 * } else {
	 * resultDurationMS = getIntent().getLongExtra(Intents.Scan.RESULT_DISPLAY_DURATION_MS,
	 * DEFAULT_INTENT_RESULT_DURATION_MS);
	 * }
	 * <p>
	 * if (resultDurationMS > 0) {
	 * String rawResultString = String.valueOf(rawResult);
	 * if (rawResultString.length() > 32) {
	 * rawResultString = rawResultString.substring(0, 32) + " ...";
	 * }
	 * statusView.setText(getString(resultHandler.getDisplayTitle()) + " : " + rawResultString);
	 * }
	 * <p>
	 * if (copyToClipboard && !resultHandler.areContentsSecure()) {
	 * CharSequence text = resultHandler.getDisplayContents();
	 * ClipboardInterface.setText(text, this);
	 * }
	 * /*
	 * if (source == IntentSource.NATIVE_APP_INTENT) {
	 * <p>
	 * // Hand back whatever action they requested - this can be changed to Intents.Scan.ACTION
	 * when
	 * // the deprecated intent is retired.
	 * Intent intent = new Intent(getIntent().getAction());
	 * intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
	 * intent.putExtra(Intents.Scan.RESULT, rawResult.toString());
	 * intent.putExtra(Intents.Scan.RESULT_FORMAT, rawResult.getBarcodeFormat().toString());
	 * byte[] rawBytes = rawResult.getRawBytes();
	 * if (rawBytes != null && rawBytes.length > 0) {
	 * intent.putExtra(Intents.Scan.RESULT_BYTES, rawBytes);
	 * }
	 * Map<ResultMetadataType,?> metadata = rawResult.getResultMetadata();
	 * if (metadata != null) {
	 * if (metadata.containsKey(ResultMetadataType.UPC_EAN_EXTENSION)) {
	 * intent.putExtra(Intents.Scan.RESULT_UPC_EAN_EXTENSION,
	 * metadata.get(ResultMetadataType.UPC_EAN_EXTENSION).toString());
	 * }
	 * Number orientation = (Number) metadata.get(ResultMetadataType.ORIENTATION);
	 * if (orientation != null) {
	 * intent.putExtra(Intents.Scan.RESULT_ORIENTATION, orientation.intValue());
	 * }
	 * String ecLevel = (String) metadata.get(ResultMetadataType.ERROR_CORRECTION_LEVEL);
	 * if (ecLevel != null) {
	 * intent.putExtra(Intents.Scan.RESULT_ERROR_CORRECTION_LEVEL, ecLevel);
	 * }
	 *
	 * @SuppressWarnings("unchecked") Iterable<byte[]> byteSegments = (Iterable<byte[]>) metadata
	 * .get(ResultMetadataType.BYTE_SEGMENTS);
	 * if (byteSegments != null) {
	 * int i = 0;
	 * for (byte[] byteSegment : byteSegments) {
	 * intent.putExtra(Intents.Scan.RESULT_BYTE_SEGMENTS_PREFIX + i, byteSegment);
	 * i++;
	 * }
	 * }
	 * }
	 * sendReplyMessage(R.id.return_scan_result, intent, resultDurationMS);
	 * <p>
	 * } else if (source == IntentSource.PRODUCT_SEARCH_LINK) {
	 * <p>
	 * // Reformulate the URL which triggered us into a query, so that the request goes to the same
	 * // TLD as the scan URL.
	 * int end = sourceUrl.lastIndexOf("/scan");
	 * String replyURL = sourceUrl.substring(0, end) + "?q=" + resultHandler.getDisplayContents()
	 * + "&source=zxing";
	 * sendReplyMessage(R.id.launch_product_query, replyURL, resultDurationMS);
	 * <p>
	 * } else if (source == IntentSource.ZXING_LINK) {
	 * <p>
	 * if (scanFromWebPageManager != null && scanFromWebPageManager.isScanFromWebPage()) {
	 * String replyURL = scanFromWebPageManager.buildReplyURL(rawResult, resultHandler);
	 * scanFromWebPageManager = null;
	 * sendReplyMessage(R.id.launch_product_query, replyURL, resultDurationMS);
	 * }
	 * <p>
	 * }
	 * }
	 */
	public void drawViewfinder() {
		codeViewfinderView.postInvalidate();
	}
}
