package com.google.zxing.client.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Point;
import android.graphics.Rect;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.view.animation.Transformation;

import com.ayke.library.util.L;
import com.ayke.library.util.SysUtils;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.DecodeHintType;
import com.google.zxing.client.android.camera.CameraManager;
import com.zxing.client.R;

import java.io.IOException;
import java.util.Collection;
import java.util.Map;

/**
 * Created by Administrator on 2015/10/9.
 */
public class ScanManager {
	private static final String TAG = "ScanManager";
	private static final Point CODE_RECT = new Point(SysUtils.dip2px(250), SysUtils.dip2px(250));
	private static final Point WORD_RECT = new Point(SysUtils.dip2px(200), SysUtils.dip2px(50));
	private static final Point CODE_LANDSCAPE_RECT = new Point(SysUtils.dip2px(250), SysUtils
			.dip2px(250));
	private static final Point WORD_LANDSCAPE_RECT = new Point(SysUtils.dip2px(300), SysUtils
			.dip2px(50));
	private Rect mCurrentRect;

	private static ScanManager mInstance;
	private Activity mActivity;
	private CaptureActivityHandler mCaptureActivityHandler;

	private BeepManager mBeepManager;
	private AmbientLightManager mAmbientLightManager;

	private CameraManager mCameraManager;
	private Collection<BarcodeFormat> decodeFormats;
	private Map<DecodeHintType, ?> decodeHints;

	private boolean isLandscape;

	private ScanMode mMode = ScanMode.CODE;

	public enum ScanMode {
		CODE,
		WORD
	}

	private ScanManager(Activity activity) {
		mActivity = activity;
		mBeepManager = new BeepManager(mActivity);
		mAmbientLightManager = new AmbientLightManager(mActivity);
	}

	public static void init(Activity activity) {
		mInstance = new ScanManager(activity);
	}

	public static ScanManager getInstance() {
		return mInstance;
	}

	public synchronized Rect getViewfinderRect() {
		if (mCurrentRect == null) {
			if (mCameraManager == null || mCameraManager.getSurfacePoint() == null)
				return null;
			Point p;
			Point surfaceP = mCameraManager.getSurfacePoint();
			int offset = 2;
			int leftOffset;
			int topOffset;
			if (isLandscape) {
				if (mMode == ScanMode.WORD) {
					p = WORD_LANDSCAPE_RECT;
					offset = 3;
				} else {
					p = CODE_LANDSCAPE_RECT;
				}
//				leftOffset = (surfaceP.y - p.x) / 2;
//				topOffset = (surfaceP.x - p.y) / offset;
			} else {
				if (mMode == ScanMode.WORD) {
					p = WORD_RECT;
					offset = 3;
				} else {
					p = CODE_RECT;
				}
			}
			leftOffset = (surfaceP.x - p.x) / 2;
			topOffset = (surfaceP.y - p.y) / offset;
			mCurrentRect = new Rect(leftOffset, topOffset, leftOffset + p.x, topOffset + p.y);
		}
		return mCurrentRect;
	}

	public synchronized void changeOrientation() {
		int or = getOrientationDegree();
		isLandscape = or == 0 || 180 == or;
		mCurrentRect = null;
		mCameraManager.updateOrientation(or);
		restartPreviewAfterDelay(0);
	}

	public synchronized void changeMode(ScanMode mode) {
		if (mMode == mode)
			return;
		mMode = mode;
		changeOrientation();
	}

	public void onResume() {
		mCameraManager = new CameraManager(mActivity);
		mCaptureActivityHandler = null;
		mBeepManager.updatePrefs(true, false);
		mAmbientLightManager.start(mCameraManager);
	}

	public void onPause() {
		if (mCaptureActivityHandler != null) {
			mCaptureActivityHandler.quitSynchronously();
			mCaptureActivityHandler = null;
		}
		mAmbientLightManager.stop();
		mBeepManager.close();
		mCameraManager.closeDriver();
	}

	public ScanMode getScanMode() {
		return mMode;
	}

	public BeepManager getBeepManager() {
		return mBeepManager;
	}

	public AmbientLightManager getAmbientLightManager() {
		return mAmbientLightManager;
	}

	public CameraManager getCameraManager() {
		return mCameraManager;
	}

	public CaptureActivityHandler getCaptureActivityHandler() {
		return mCaptureActivityHandler;
	}

	public int getOrientationDegree() {
		int rotation = mActivity.getWindowManager().getDefaultDisplay().getRotation();
		switch (rotation) {
			case Surface.ROTATION_0:
				return 90;
			case Surface.ROTATION_90:
				return 0;
			case Surface.ROTATION_180:
				return 270;
			case Surface.ROTATION_270:
				return 180;
			default:
				return 0;
		}
	}

	public void initCamera(SurfaceHolder surfaceHolder) {
		if (surfaceHolder == null) {
			throw new IllegalStateException("No SurfaceHolder provided");
		}
		if (mCameraManager.isOpen()) {
			Log.w(TAG, "initCamera() while already open -- late SurfaceView callback?");
			return;
		}
		try {
			mCameraManager.openDriver(surfaceHolder);
			// Creating the handler starts the preview, which can also throw a RuntimeException.
			if (mCaptureActivityHandler == null) {
				mCaptureActivityHandler = new CaptureActivityHandler((CaptureActivity) mActivity,
						decodeFormats, decodeHints,
						null, mCameraManager);
			}
			mCameraManager.updateOrientation(90);
			restartPreviewAfterDelay(100);
		} catch (IOException ioe) {
			Log.w(TAG, ioe);
			displayFrameworkBugMessageAndExit();
		} catch (RuntimeException e) {
			// Barcode Scanner has seen crashes in the wild of this variety:
			// java.?lang.?RuntimeException: Fail to connect to camera service
			Log.w(TAG, "Unexpected error initializing camera", e);
			displayFrameworkBugMessageAndExit();
		}
	}

	private void displayFrameworkBugMessageAndExit() {
		AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
		builder.setTitle(mActivity.getString(R.string.app_name));
		builder.setMessage(mActivity.getString(R.string.msg_camera_framework_bug));
		builder.setPositiveButton(R.string.button_ok, new FinishListener(mActivity));
		builder.setOnCancelListener(new FinishListener(mActivity));
		builder.show();
	}

	public void restartPreviewAfterDelay(long delayMS) {
		if (mCaptureActivityHandler != null) {
			mCaptureActivityHandler.sendEmptyMessageDelayed(R.id.restart_preview, delayMS);
		}
	}

	public String getFilePath() {
		if (mActivity != null) {
			return mActivity.getFilesDir().getAbsolutePath();
		}
		return "";
	}
}
