/*
 * Copyright (C) 2010 ZXing authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.zxing.client.android;

import android.graphics.Bitmap;

import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.PlanarYUVLuminanceSource;
import com.google.zxing.ReaderException;
import com.google.zxing.Result;
import com.google.zxing.common.HybridBinarizer;
import com.googlecode.tesseract.android.TessBaseAPI;
import com.zxing.client.R;

import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.Map;

final class DecodeHandler extends Handler {
	private static final String TAG = DecodeHandler.class.getSimpleName();
	private final MultiFormatReader multiFormatReader;
	private boolean running = true;

	public DecodeHandler(Map<DecodeHintType, Object> hints) {
		multiFormatReader = new MultiFormatReader();
		multiFormatReader.setHints(hints);
	}

	@Override
	public void handleMessage(Message message) {
		if (!running) {
			return;
		}
		switch (message.what) {
			case R.id.decode:
				if (ScanManager.getInstance().getScanMode() == ScanManager.ScanMode.CODE) {
					decode((byte[]) message.obj, message.arg1, message.arg2);
				} else if (ScanManager.getInstance().getScanMode() == ScanManager.ScanMode.WORD) {
					decodeWord((byte[]) message.obj, message.arg1, message.arg2);
				}
				break;
			case R.id.quit:
				running = false;
				if (baseApi != null)
					baseApi.end();
				Looper.myLooper().quit();
				break;
		}
	}

	/**
	 * Decode the data within the viewfinder rectangle, and time how long it took. For efficiency,
	 * reuse the same reader objects from one decode to the next.
	 *
	 * @param data   The YUV preview frame.
	 * @param width  The width of the preview frame.
	 * @param height The height of the preview frame.
	 */
	private void decode(byte[] data, int width, int height) {
		long start = System.currentTimeMillis();
		Result rawResult = null;
		PlanarYUVLuminanceSource source = ScanManager.getInstance().getCameraManager()
				.buildLuminanceSource(data,
						width, height);
		if (source != null) {
			BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));
			try {
				rawResult = multiFormatReader.decodeWithState(bitmap);
			} catch (ReaderException re) {
				// continue
			} finally {
				multiFormatReader.reset();
			}
		}

		Handler handler = ScanManager.getInstance().getCaptureActivityHandler();
		if (rawResult != null) {
			// Don't log the barcode contents for security.
			long end = System.currentTimeMillis();
			Log.d(TAG, "Found barcode in " + (end - start) + " ms");
			if (handler != null) {
				Message message = Message.obtain(handler, R.id.decode_succeeded, rawResult);
				Bundle bundle = new Bundle();
				bundleThumbnail(source, bundle);
				message.setData(bundle);
				message.sendToTarget();
			}
		} else {
			if (handler != null) {
				Message message = Message.obtain(handler, R.id.decode_failed);
				message.sendToTarget();
			}
		}
	}

	TessBaseAPI baseApi;

	private void decodeWord(byte[] data, int width, int height) {
		PlanarYUVLuminanceSource pls = ScanManager.getInstance().getCameraManager()
				.buildLuminanceSource(data,
						width,
						height);
//    Pix source = activity.getCameraManager().buildPixSource(data,width,height);
		int[] pixels = pls.renderThumbnail();
		int w = pls.getThumbnailWidth();
		int h = pls.getThumbnailHeight();
		switch (ScanManager.getInstance().getOrientationDegree()) {
			case 90:
				pixels = rotate90(pixels, w, h);
				w = pls.getThumbnailHeight();
				h = pls.getThumbnailWidth();
				break;
			case 180:
				pixels = rotate180(pixels);
				break;
			case 270:
				pixels = rotate270(pixels, w, h);
				w = pls.getThumbnailHeight();
				h = pls.getThumbnailWidth();
				break;
		}
		Bitmap bitmap = Bitmap.createBitmap(pixels, 0, w, w, h, Bitmap.Config.ARGB_8888);
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		if (baseApi == null) {
			baseApi = new TessBaseAPI();
			baseApi.init(ScanManager.getInstance().getFilePath(), "eng");
		}
		baseApi.setImage(bitmap);
		String text = baseApi.getUTF8Text();
		text = text.replaceAll("\\W", "");
		Log.d("ayke", " text=" + text);
		baseApi.clear();
		Handler handler = ScanManager.getInstance().getCaptureActivityHandler();
		if (handler != null) {
			Message message = Message.obtain(handler, R.id.decode_word, text);
			Bundle bundle = new Bundle();
			bitmap.compress(Bitmap.CompressFormat.JPEG, 50, out);
			bundle.putByteArray(DecodeThread.BARCODE_BITMAP, out.toByteArray());
			message.setData(bundle);
			message.sendToTarget();
		}
	}

	/**
	 * 获取sd卡的路径
	 *
	 * @return 路径的字符串
	 */
	public String getSDPath() {
		File sdDir = null;
		boolean sdCardExist = Environment.getExternalStorageState().equals(
				android.os.Environment.MEDIA_MOUNTED); // 判断sd卡是否存在
		if (sdCardExist) {

			sdDir = Environment.getExternalStorageDirectory();// 获取外存目录
		}
		return sdDir.toString();
	}

	private static void bundleThumbnail(PlanarYUVLuminanceSource source, Bundle bundle) {
		int[] pixels = source.renderThumbnail();
		int width = source.getThumbnailWidth();
		int height = source.getThumbnailHeight();
		Bitmap bitmap = Bitmap.createBitmap(pixels, 0, width, width, height, Bitmap.Config
				.ARGB_8888);
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		bitmap.compress(Bitmap.CompressFormat.JPEG, 50, out);
		bundle.putByteArray(DecodeThread.BARCODE_BITMAP, out.toByteArray());
		bundle.putFloat(DecodeThread.BARCODE_SCALED_FACTOR, (float) width / source.getWidth());
	}

	private static int[] rotate90(int[] data, int width, int height) {
		int[] tempData = new int[data.length];
		int n = 0;
		for (int i = 0; i < width; i++) {
			for (int j = 0; j < height; j++) {
				tempData[n++] = data[(height - j - 1) * width + i];
			}
		}
		return tempData;
	}

	private static int[] rotate180(int[] data) {
		int temp;
		for (int i = 0; i < data.length / 2; i++) {
			temp = data[i];
			data[i] = data[data.length - i - 1];
			data[data.length - i - 1] = temp;
		}
		return data;
	}

	private static int[] rotate270(int[] data, int width, int height) {
		int[] tempData = new int[data.length];
		int n = 0;
		for (int i = 0; i < width; i++) {
			for (int j = 0; j < height; j++) {
				tempData[n++] = data[j * width + (width - i - 1)];
			}
		}
		return tempData;
	}


}
